import"./init.D87yOSev.js";import"./Index.MPC-g2At.js";
//# sourceMappingURL=webworkerAll.BwCCo0G0.js.map
