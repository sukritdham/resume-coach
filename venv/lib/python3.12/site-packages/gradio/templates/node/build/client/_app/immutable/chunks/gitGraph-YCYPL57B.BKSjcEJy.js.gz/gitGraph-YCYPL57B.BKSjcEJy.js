import{G as a,f as G}from"./mermaid-parser.core.BTiWe88f.js";export{a as GitGraphModule,G as createGitGraphServices};
//# sourceMappingURL=gitGraph-YCYPL57B.BKSjcEJy.js.map
