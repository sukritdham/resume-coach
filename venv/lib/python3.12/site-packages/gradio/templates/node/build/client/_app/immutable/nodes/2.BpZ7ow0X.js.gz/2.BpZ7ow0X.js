import{Z as e,_ as n}from"../chunks/2.CXBv8kT_.js";export{e as component,n as universal};
//# sourceMappingURL=2.BpZ7ow0X.js.map
