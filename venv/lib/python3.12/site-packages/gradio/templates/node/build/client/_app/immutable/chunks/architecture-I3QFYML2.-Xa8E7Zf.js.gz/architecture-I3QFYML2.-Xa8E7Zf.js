import{A as c,e as t}from"./mermaid-parser.core.BTiWe88f.js";export{c as ArchitectureModule,t as createArchitectureServices};
//# sourceMappingURL=architecture-I3QFYML2.-Xa8E7Zf.js.map
