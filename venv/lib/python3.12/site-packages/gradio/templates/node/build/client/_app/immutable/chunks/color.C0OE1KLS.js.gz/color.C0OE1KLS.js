import{v as o}from"./2.CXBv8kT_.js";const t=r=>o[r%o.length];export{t as g};
//# sourceMappingURL=color.C0OE1KLS.js.map
